package com.cg.spring.core.beans;

import java.util.List;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Customer implements InitializingBean, DisposableBean {
    private int id;
    private String name;
    private List<Product> list;
    
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
    public List<Product> getList() {
		return list;
	}
	public void setList(List<Product> list) {
		this.list = list;
	}
	public void showProducts() {
		for (Product p : list) {
			System.out.println("name: "+p.getProduct_name());
			System.out.println("price: "+p.getProduct_price());
			System.out.println("-----------------------------");
		}
	}
	public void afterPropertiesSet() throws Exception {
		System.out.println("");
		System.out.println("Init method for customers");	
		System.out.println("_________________________");
	}
	public void destroy() throws Exception {
		System.out.println("");
		System.out.println("Destroy method for customers");	
		System.out.println("____________________________");
	}
}
