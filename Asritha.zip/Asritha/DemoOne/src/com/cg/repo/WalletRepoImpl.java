package com.cg.repo;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Customer;

public class WalletRepoImpl implements WalletRepo {
	private static Map<String, Customer> map = null;
	static {
		map = new HashMap<String, Customer>();
	}

	@Override
	public boolean save(Customer customer) {
		boolean result = false;
		if (!(map.containsKey(customer.getMobileNo()))) {
			map.put(customer.getMobileNo(), customer);
			result = true;
		}
		return result;
	}

	@Override
	public Customer findOne(String mobileNo) {
		// TODO Auto-generated method stub
		return map.get(mobileNo);
	}

}
