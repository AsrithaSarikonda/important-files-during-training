package com.capg.WalletApp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.swing.text.DefaultEditorKit.CutAction;

import com.capg.WalletApp.bean.Customer;
import com.capg.WalletApp.util.JPAUtil;

public class WalletApplicationDao implements IWalletApplicationDao {

	private static EntityManager entityManager = null;
	Customer cust = null, customer = null;
	static {
		entityManager = JPAUtil.getEntityManager();
	}

	public Customer getDetails(String username) {

		entityManager.getTransaction().begin();
		cust = entityManager.find(Customer.class, username);
		entityManager.getTransaction().commit();
		return cust;

	}

	public int createAccount(Customer customer) throws Exception {
		entityManager.getTransaction().begin();
		customer.setTransactions("Account Created On\t"+LocalDateTime.now());
		entityManager.persist(customer);
		entityManager.getTransaction().commit();
		return 1;
	}

	public boolean login(String username, String password) throws Exception {
		boolean res = false;
		entityManager.getTransaction().begin();
		customer = entityManager.find(Customer.class, username);
		if (customer != null) {
			res = true;
		}
		entityManager.getTransaction().commit();

		return res;
	}

	public float showBalance() {
		return (float) customer.getAmount();
	}

	public int deposit(float amount) {
		customer.setAmount(customer.getAmount() + amount);
		customer.setTransactions(customer.getTransactions()+"\n"+amount+" deposited at "+LocalDateTime.now());
		return (int) customer.getAmount();
	}

	public int withdraw(float amount) {
		customer.setAmount(customer.getAmount() - amount);
		customer.setTransactions(customer.getTransactions()+"\n"+amount+" withdrawn at "+LocalDateTime.now());
		
		return (int) customer.getAmount();
	}

	public int fundTransfer(String un, float amount) {
		entityManager.getTransaction().begin();
		customer.setAmount(customer.getAmount() - amount);
		customer.setTransactions(customer.getTransactions()+"\n"+amount+" deposited at "+LocalDateTime.now());
		Customer recCust = entityManager.find(Customer.class, un);
		recCust.setAmount(recCust.getAmount() + amount);
		recCust.setTransactions(recCust.getTransactions()+"\n"+amount+" withdrawn at "+LocalDateTime.now());
		
		entityManager.getTransaction().commit();
		return (int) customer.getAmount();
	}

	public void printTransaction() {
		System.out.println(customer.getTransactions());
	}

}
