package com.cg.spring.SpringDataJPA.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.SpringDataJPA.beans.Product;
import com.cg.spring.SpringDataJPA.repo.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository repo;
	
	@Override
	public void addProduct(Product p) {
		repo.save(p);
	}

	@Override
	public void updateProduct(Product p, String id) {
		repo.save(p);
	}

	@Override
	public void deleteProduct(String id) {
		repo.deleteById(id);
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> list = new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
	}

	@Override
	public Optional<Product> getProductById(String id) {
		return repo.findById(id);
	}

}
