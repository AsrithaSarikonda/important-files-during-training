package com.cg.basic;

public class Triangle {
      public void draw() { 
    	  System.out.println("Drawing in triangle");
      }
      Point point;
      
}
