package com.cg.basic;

public class DrawingApp {
   public static void main(String[] args) {
	Triangle triangle = new Triangle();
	triangle.draw();
}
}
