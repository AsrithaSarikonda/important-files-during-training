package com.cg.spring.repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.dto.Product;

@Repository("productrepo")
public class ProductRepoImpl implements ProductRepo{

	public static ArrayList<Product> list = null;
	static {
		list = new ArrayList<>();
		
		Product p1 = new Product("Htc816","HTC","HTC Desire", "20000");
		Product p2 = new Product("One01","OnePlus","One Plus 5T", "32000");
		list.add(p1);
		list.add(p2);
	}
	
	@Override
	public List<Product> getAllProducts() {
		return list;
	}

	@Override
	public Product getProductById(String id) {
		for(Product product:list) {
			if(product.getId().equals(id)) {
				return product;
			}
		}
		return null;
	}

	@Override
	public void addProduct(Product p) {
		list.add(p);
	}

	@Override
	public void deleteProduct(String id) {
		for(Product product: list) {
			if(product.getId().equals(id)) {
				list.remove(product);
			}
		}
	}

	@Override
	public void updateProduct(Product p, String id) {
		for(int i = 0; i <list.size(); i++) {
			if(list.get(i).getId().equals(id)) {
				list.set(i, p);
			}
		}
	}
}
