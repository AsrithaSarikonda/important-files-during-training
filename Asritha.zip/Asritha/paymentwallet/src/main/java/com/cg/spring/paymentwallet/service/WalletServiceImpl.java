package com.cg.spring.paymentwallet.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.spring.paymentwallet.bean.Customer;
import com.cg.spring.paymentwallet.repo.WalletRepository;

public class WalletServiceImpl implements WalletService{

	@Autowired
	private WalletRepository repo;
	
	
	@Override
	public void createAccount(Customer customer) {
		repo.save(customer);
	}

	

	@Override
	public float showBalance(String username) {
		repo.findById(username);
	}

	@Override
	public void deposit(float amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdraw(float amount) {
		// TODO Auto-generated method stub
		
	}

	
	
}
