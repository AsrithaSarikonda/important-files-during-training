package com.cg.spring.paymentwallet.service;

import com.cg.spring.paymentwallet.bean.Customer;

public interface WalletService {

	public void createAccount(Customer customer);
	/*public void login(String username, String password);*/
	public float showBalance(String username);
	public void deposit(float amount);
	public void withdraw(float amount);
	/*public int fundTransfer(String un, float amount);
	public void printTransaction();
		*/
}
