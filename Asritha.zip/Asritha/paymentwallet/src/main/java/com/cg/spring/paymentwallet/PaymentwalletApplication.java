package com.cg.spring.paymentwallet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentwalletApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentwalletApplication.class, args);
	}
}
