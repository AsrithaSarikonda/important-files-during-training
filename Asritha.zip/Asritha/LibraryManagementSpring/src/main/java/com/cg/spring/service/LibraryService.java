package com.cg.spring.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.beans.Library;
import com.cg.spring.repo.LibraryRepository;

@Service
public class LibraryService implements ILibraryService{

	@Autowired
	private LibraryRepository repo;
	
	@Override
	public void addBook(Library library) {
		repo.save(library);		
	}

	@Override
	public void deleteBook(int id) {
		repo.deleteById(id);	
	}

	@Override
	public void updateBook(Library library, int id) {
		library.setId(id);
		repo.save(library);
	}

	@Override
	public List<Library> displaybooks() {
		List<Library> list = new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
	}
   
	@Override
	public Optional<Library> getLibraryById(int id) {
		return repo.findById(id);
	}
}
