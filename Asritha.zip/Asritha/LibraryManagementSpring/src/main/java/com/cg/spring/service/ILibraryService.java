package com.cg.spring.service;

import java.util.List;
import java.util.Optional;

import com.cg.spring.beans.Library;

public interface ILibraryService {
   public void addBook(Library library);
   public void deleteBook(int id);
   public void updateBook(Library library, int id);
   public List<Library> displaybooks();
   public Optional<Library> getLibraryById(int id);
}
