package com.cg.spring.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.beans.Library;
import com.cg.spring.service.LibraryService;


@RestController
public class LibraryController {
	@Autowired
	private LibraryService service;
	
	@RequestMapping("/library")
    public List<Library> displayBooks() {
		return service.displaybooks();
    }
	
	@RequestMapping("/library/{id}")
	public Optional<Library> getLibraryById(@PathVariable int id) {
		return service.getLibraryById(id);
	}
	
	@RequestMapping(value="/library", method = RequestMethod.POST)
	public void addBook(@RequestBody Library l) {
		service.addBook(l);
	}
	
	@RequestMapping(value="/library/{id}", method = RequestMethod.DELETE)
	public void deleteBook(@PathVariable int id) {
		service.deleteBook(id);
	}

	@RequestMapping(value="/library/{id}", method = RequestMethod.PUT)
	public void updateProduct(@RequestBody Library library,@PathVariable int id) {
		service.updateBook(library,id);
	}

}
