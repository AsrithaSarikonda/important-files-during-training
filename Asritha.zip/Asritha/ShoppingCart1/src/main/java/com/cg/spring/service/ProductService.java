package com.cg.spring.service;

import java.util.List;

import com.cg.spring.dto.Product;
import com.cg.spring.exception.ProductException;

public interface ProductService {
	
	public List<Product> getAllProducts();
	public void updateProduct(Integer id,Product product) throws ProductException;
	public void deleteProduct(Integer id) throws ProductException;
	public void addProduct(Product product);
	public Product searchProduct(Integer id) throws ProductException;

}
