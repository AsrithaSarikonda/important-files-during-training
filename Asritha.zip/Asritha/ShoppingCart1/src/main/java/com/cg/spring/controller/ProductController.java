package com.cg.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.dto.Product;
import com.cg.spring.exception.ProductException;
import com.cg.spring.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private ProductService service;

	@RequestMapping("/products")
	public List<Product> Products() {
		return service.getAllProducts();
	}

	@RequestMapping("/products/{id}")
	public Object getProductById(@PathVariable Integer id) {
		try {
			return service.searchProduct(id);
		} catch (ProductException e) {
			return e.getMessage();
		}

	}

	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public void addProduct(@RequestBody Product p) {
		service.addProduct(p);
	}

	@RequestMapping(value = "/products/{id}", method = RequestMethod.DELETE)
	public String DeleteProduct(@PathVariable Integer id) {
		String str = null;
		try {
			service.deleteProduct(id);
			str = "Product Deleted";
		} catch (ProductException e) {
			str = e.getMessage();
		}
		return str;
	}

	@RequestMapping(value = "/products/{id}", method = RequestMethod.PUT)
	public String UpdateProduct(@PathVariable Integer id, @RequestBody Product p) {
		String str = null;
		try {
			service.updateProduct(id, p);
			str = "Updated Successfully";
		} catch (ProductException e) {
			str = e.getMessage();
		}
		return str;
	}

}
