package com.capg.WalletApp.service;

import java.util.List;

import com.capg.WalletApp.bean.Customer;
import com.capg.WalletApp.dao.WalletApplicationDao;

public class WalletApplicationService implements IWalletApplicationService{
	WalletApplicationDao dao = new WalletApplicationDao();

	public int createAccount(Customer customer) throws Exception {
		return dao.createAccount(customer);
	}

	public boolean login(String username, String password) throws Exception {
		return dao.login(username, password);
	}

	public float showBalance() {
		return dao.showBalance();
	}

	public int deposit(float amount) {
		return dao.deposit(amount);
	}

	public int withdraw(float amount) {
		return dao.withdraw(amount);
	}

	public int fundTransfer(int accNo, float amount) {
		return dao.fundTransfer(accNo, amount);
	}

	public void printTransaction() {
		dao.printTransaction();
	}
}
