package com.cg.spring.productcart.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.productcart.dto.Product;
import com.cg.spring.productcart.exception.ProductException;
import com.cg.spring.productcart.repo.IProductRepo;


@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductRepo repo;

	@Override
	public List<Product> getAllProducts() {
		List<Product> list = new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
	}

	@Override
	public void deleteProduct(String id) throws ProductException {
		if (repo.existsById(id)) {
			repo.deleteById(id);

		} else {
			throw new ProductException("Product Not Found");
		}
	}

	@Override
	public void addProduct(Product product) {
		repo.save(product);
	}

	@Override
	public void updateProduct(String id, Product product) throws ProductException {
		if (repo.existsById(id)) {
			product.setId(id);
			repo.save(product);

		} else {
			throw new ProductException("Product Not Found");
		}
	}

	@Override
	public Product searchProduct(String id) throws ProductException {
		Product pro = null;
		if (repo.existsById(id)) {
			pro = repo.findById(id).get();

		} else {
			throw new ProductException("Product Not Found");
		}
		return pro;

	}

}
