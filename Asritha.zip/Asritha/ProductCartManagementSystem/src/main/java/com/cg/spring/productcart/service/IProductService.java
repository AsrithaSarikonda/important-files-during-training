package com.cg.spring.productcart.service;

import java.util.List;

import com.cg.spring.productcart.dto.Product;
import com.cg.spring.productcart.exception.ProductException;

public interface IProductService {
	public List<Product> getAllProducts();
	public void updateProduct(String id,Product product) throws ProductException;
	public void deleteProduct(String id) throws ProductException;
	public void addProduct(Product product);
	public Product searchProduct(String id) throws ProductException;
	
	
}
