package com.cg.spring.productcart.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.productcart.dto.Product;

@Repository
public interface IProductRepo extends CrudRepository<Product, String> {

}
