package com.capgemini.PaymentApplication.bean;

import junit.framework.TestCase;

public class CustomerTest extends TestCase {
	Customer cust = new Customer();

	public void testGetUserName() {
		cust.setUserName("asritha@1207");
		assertEquals("asritha@1207",cust.getUserName());
	}



	public void testGetPassword() {
		cust.setPassword("asri@1207");
		assertEquals("akki@1207",cust.getPassword());
		
	}


	public void testGetFirstName() {
		cust.setFirstName("asritha");
		assertEquals("asritha", cust.getFirstName());
		assertTrue("asritha".equalsIgnoreCase(cust.getFirstName()));
		assertNotNull(cust);
	}

	

	public void testGetLastName() {
		cust.setLastName("sarikonda");
		assertEquals("sarikonda", cust.getLastName());
		assertTrue("sarikonda".equalsIgnoreCase(cust.getLastName()));
		assertNotNull(cust);
	}

	

	public void testGetGender() {
		cust.setGender("female");
		assertFalse("male".equalsIgnoreCase(cust.getGender()));
		assertTrue("female".equalsIgnoreCase(cust.getGender()));
	}

	

	public void testGetContact() {
		cust.setContact("9177187085");
		assertFalse("9177187085".equals(cust.getContact()));
		assertTrue("9177187085".equals(cust.getContact()));
	}

	

	public void testGetEmail() {
		cust.setEmail("asritha@gmail.com");
		assertEquals("asritha@gmail.com",cust.getEmail());
	
	}



	public void testGetAge() {
		cust.setAge(23);
		assertEquals(23, cust.getAge());
	}

	
	public void testGetAadharNo() {
		cust.setAadharNo("1235467890");
		assertTrue("1235467890".equals(cust.getAadharNo()));
		assertFalse("1246467890".equals(cust.getAadharNo()));
		
	}

	

	

}
